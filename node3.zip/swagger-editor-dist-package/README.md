This module, `swagger-editor-dist`, exposes Swagger-Editor's entire dist folder as a dependency-free npm module.

Use `swagger-editor` instead, if you'd like to have npm install dependencies for you.
